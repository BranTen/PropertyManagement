package assignment4;

public class Property {
private String city;
private String owner;
private String propertyName;
private double rentAmount;

/**
 * constructor
 * @param propertyName
 * @param city
 * @param rentAmount
 * @param owner
 */
public Property(String propertyName, String city, double rentAmount, String owner){
	setPropertyName(propertyName);
	setLoc(city);
	setRentAmount(rentAmount);
	setOwner(owner);
}
public Property(Property p){
	city = p.city;
	owner = p.owner;
	propertyName = p.propertyName;
	rentAmount = p.rentAmount;
}
/**
 * this method returns the city
 * @return
 */
public String getCity(){
	
	return city;
	
}
/**
 * this method returns the owner
 * @return
 */
public String getOwner(){
	
	return owner;
	
}
/**
 * this method returns the property name
 * @return
 */
public String getPropertyName(){
	
	return propertyName;
	
}
/**
 * this method returns the rent amount
 * @return
 */
public double getRentAmount(){
	
	return rentAmount;
	
}
/**
 * this method sets the city
 * @param city
 */
public void setLoc(String city){
	this.city = city;
}
/**
 * this method sets the owner
 * @param owner
 */
public void setOwner(String owner){
	this.owner = owner;
}
/**
 * this method sets the property name
 * @param propertyName
 */
public void setPropertyName(String propertyName){
	this.propertyName = propertyName;
}
/**
 * this method sets the rent amount
 * @param rentAmount
 */
public void setRentAmount(double rentAmount){
	this.rentAmount = rentAmount;
}
/**
 * this method returns
 */
public String toString(){
	return "Property Name: " + getPropertyName() + "\nLocated in: " + getCity() + "\n"
			+ "Belonging to: " + getOwner() + "\nRent Amount: " + getRentAmount();
	
}

}