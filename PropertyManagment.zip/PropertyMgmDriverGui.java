package assignment4;
import java.io.IOException;

import com.sun.security.auth.callback.TextCallbackHandler;

import javafx.application.Application;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.event.EventTarget;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
/**
 * this class is a gui class that displays all of the application and sets events for each of the buttons
 * @author Brandon
 *
 */

public class PropertyMgmDriverGui extends Application{
//create all of the buttons and text fields and boxes
	TextField name = new TextField();
	TextField city = new TextField();
	TextField rent = new TextField();
	TextField owner = new TextField();
	//---------------------------
	TextField mgmName = new TextField();
	TextField taxID = new TextField();
	TextField fee = new TextField();
	//---------------------------
	Button newMgmComp = new Button("New Management Company");
	Button add = new Button("Add Property");
	Button max = new Button("Max Rent");
	Button total = new Button ("Total Rent");
	Button list = new Button ("List of Properties");
	Button exit = new Button("Exit");

	HBox bRow1 = new HBox();
	HBox bRow2 = new HBox();
	VBox buttons = new VBox();
	VBox main = new VBox();
// create management company object
	ManagementCompany m;
	//create property object
	Property p;

	/**
	 * this method is the start method and compiles and designes the gui format
	 */
	@Override
	public void start(Stage stage) {

		// create pane objects
		TitledPane t1 = new TitledPane();
		TitledPane t2 = new TitledPane();
		GridPane gridPane1 = new GridPane();
		GridPane gridPane2 = new GridPane();
		GridPane gridPane3 = new GridPane();	
		
		//disable some buttons for now
		add.setDisable(true);
		max.setDisable(true);
		total.setDisable(true);
		list.setDisable(true);
		
		//set these buttons on an action
		newMgmComp.setOnAction(new ButtonHandler());
		add.setOnAction(new ButtonHandler());
		max.setOnAction(new ButtonHandler());
		total.setOnAction(new ButtonHandler());
		list.setOnAction(new ButtonHandler());
		exit.setOnAction(new ButtonHandler());

		//add buttons to the appropriate boxes
		bRow1.getChildren().addAll(newMgmComp, add, max);
		bRow2.getChildren().addAll(total,list, exit);
		bRow1.setAlignment(Pos.CENTER);
		bRow2.setAlignment(Pos.CENTER);
		
		//set spacing for buttons to make it look pretty
		bRow1.setSpacing(5);
		bRow2.setSpacing(5);
		buttons.setSpacing(5);
		buttons.getChildren().addAll(bRow1, bRow2);

		//place the labels in the gridpanes and the textfields
		gridPane1.add(new Label("Name"),0 ,0);
		gridPane1.add(mgmName,1 ,0);
		gridPane1.add(new Label("Tax ID"),2 ,0);
		gridPane1.add(taxID,3 ,0);
		gridPane1.add(new Label("Fee%"),4 ,0);
		gridPane1.add(fee,5 ,0);

		gridPane2.add(new Label("Property Name"),0 ,0);
		gridPane2.add(name,0,1);
		gridPane2.add(new Label("City"),0, 2);
		gridPane2.add(city,0,3);
		gridPane2.add(new Label("Rent"),0, 4);
		gridPane2.add(rent,0,5);
		gridPane2.add(new Label("Owner"),0, 6);
		gridPane2.add(owner,0,7);
		gridPane3.add( buttons,0 ,0);

		//space that out
		gridPane1.setHgap(5);
		gridPane2.setHgap(5);
		gridPane3.setHgap(5);

		gridPane1.setVgap(5);
		gridPane2.setVgap(5);
		gridPane3.setVgap(5);
		//set it to the center
		gridPane1.setAlignment(Pos.CENTER);
		gridPane2.setAlignment(Pos.CENTER);

		//set the titled panes (title, node)
		t1 = new TitledPane("ManagemantCompany", gridPane1);
		t2 = new TitledPane("Property Information", gridPane2);
		//set the buttons to the center
		gridPane3.setAlignment(Pos.CENTER);

		//restrict the titled panes
		t1.setMaxWidth(600);
		t2.setMaxWidth(70);

		//make the scene and set the size
		Scene scene = new Scene(main, 600, 400);	
		// add the nodes
		main.getChildren().addAll(t1, t2, gridPane3);
		main.setAlignment(Pos.CENTER);
		// set the title of the main stage
		stage.setTitle("Rental Management");
		stage.setScene(scene);
		stage.show(); // show stage

	}
	/**
	 * this method handles all of the button actions 
	 * @author Brandon
	 *
	 */
	private  class ButtonHandler implements EventHandler<ActionEvent>{
		public void handle(ActionEvent event){

			
			if (event.getTarget() == newMgmComp){// first button
				//get the text that is in the text boxes
				String name = mgmName.getText();
				String tax = taxID.getText();
				String s = fee.getText();
				//convetrt the fee to an int
				int fee = Integer.parseInt(s);
				//create new managemnet company object
				m = new ManagementCompany(name, tax, fee);
				//disable/enable buttons
				newMgmComp.setDisable(true);
				add.setDisable(false);
				max.setDisable(false);
				total.setDisable(false);
				list.setDisable(false);
			}else 
				if (event.getTarget() == add ){//second button
					String n = name.getText();
					String c = city.getText();
					String r = rent.getText();
					double r1 = Double.parseDouble(r); 
					String o = owner.getText();
					//create property object
					p = new Property(n, c, r1, o);
					//add the property object
					m.addProperty(p);
				}else
					if(event.getTarget() == max){
						maxToString();//function call
					}else
						if(event.getTarget() == total){
							totalToString();//function call
						}else
							if(event.getTarget() == list){
								listToString();//function call
							}else
								if(event.getTarget() == exit){
									Platform.exit();//exit program
									System.exit(0);
								}
		}

		private void listToString() {
			//this creates a popup box type information, displays information on the listings
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Management Company");
			alert.setHeaderText("All Listings");
			alert.setContentText(m.toString());
			alert.showAndWait();
		}

		private void totalToString() {
			//this displays the total rent in a pop up box
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Management Company");
			alert.setHeaderText("Total Management Fee");

			double per = m.totalRent() * m.mgmFee();
			per = per / 100;

			alert.setContentText("list of all properties for " + m.Company() + "\n\n\n" 
					+ m.toString() + "\n\nTotal Management Fee: " + per);

			alert.showAndWait();
		}

		private void maxToString() {
			// display the max property 
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Management Company");
			alert.setHeaderText("Max Rent");

			alert.setContentText(m.displayPropertyAtIndex(m.maxPropertyRentIndex()));
			alert.showAndWait();
		}	
	}
}


