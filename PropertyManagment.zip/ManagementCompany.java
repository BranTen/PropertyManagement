package assignment4;

public class ManagementCompany {
private int MAX_PROPERTY = 5;
private double mgmFeePer;
private String name;
private Property[] properties = new Property [MAX_PROPERTY];
private String taxID;
private int aSize;
private int propertiesIndex = -1;

public ManagementCompany(String name, String taxID, int mgmFeePer) {
	this.name = name;
	this.taxID = taxID;
	this.mgmFeePer = mgmFeePer;
	//propertiesIndex = -1;

}
public String Company(){
	String company;
	company = name + " ,TaxID: " + taxID + " " ;
	return company;
}
public double mgmFee(){
	return mgmFeePer;
}
/**
 * this method return the max property
 * @return
 */
public int getMAX_PROPERTY(){
	return MAX_PROPERTY;
}
/**
 * this method adds a property object to the array properties
 * @param property
 * @return
 */
public int addProperty(Property property){
	propertiesIndex++;
	if (propertiesIndex >= MAX_PROPERTY){
		return -1;
	}
	properties[propertiesIndex] = property;
	return propertiesIndex;
}

/**
 * this method finds and returns the sum of all of the rent amounts
 * @return
 */
public double totalRent(){
	double totalRent = 0;
	int i;
	if(propertiesIndex < 4){
		for (i = 0; i <= propertiesIndex; i++){
			
			totalRent += properties[i].getRentAmount();
		}
		return totalRent;
	}else
	
	for (i = 0; i < propertiesIndex; i++){
		
		totalRent += properties[i].getRentAmount();
	}
	return totalRent;
	
	
	
}
/**
 * this method finds out the maximum rent and returns it 
 * 
 * @return
 */

public int maxPropertyRentIndex(){
    double max = properties[0].getRentAmount(); // start at index 0
    int rentIndex =0;
    
    for (int i = 0; i < propertiesIndex; i++)//for the length of the array...
    {
       if (properties[i].getRentAmount() > max)// if the current index is greater than the current max
       {
          rentIndex = i; // record the index where the maximum is
          max = properties[i].getRentAmount(); // set the new max
       }
       
    }
    
	return rentIndex;
}
/**
 * this method displays the information at a specific index
 * @param i
 * @return
 */
public String displayPropertyAtIndex(int i){
	
	String s;
	s = "Property Name: " + properties[i].getPropertyName() + "\nLocated in: " + properties[i].getCity() + "\n"
			+ "Belonging to: " + properties[i].getOwner() + "\nRent Amount: " + properties[i].getRentAmount();
	return s;
}
/**
 * this method displays all of the informations
 */
public String toString(){
	
String message = "";
for(int i = 0; i < MAX_PROPERTY; i++){
	message += properties[i] + "\n\n";
}
return message;
}
}
